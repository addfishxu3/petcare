package com.example.petcare

const val PHARMACIES_DATA_URL="https://www.afurkid.com/Veterinary/json"